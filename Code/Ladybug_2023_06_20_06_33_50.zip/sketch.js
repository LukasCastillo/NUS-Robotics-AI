                    
/* 
 *  C06 - p5.js Screen Control Simple Robot
 *  Creating a fancy interactive user interface 
 *  capable of communicating via the Browser/Phone's Screen
 *  in p5.js
 *  
 */

var leftMove = false;
var rightMove = false;
var goButton;

var ButtonSize = 200;

function setup() {
  createCanvas(windowWidth,windowHeight);
  console.log("connecting")
  
  //direct movement buttons
  makeButton((windowWidth - ButtonSize) /2,100,"green","GO",true,true)
  makeButton(0,0,"green","Left",true,false)
  makeButton(windowWidth - ButtonSize,0,"green","Right",false,true)
  makeButton(windowWidth - ButtonSize,0,"green","Right",false,true)
  
  //the buttons for the feelers 
  makeButton(0,100,"red","Touchy",false,false,()=>{
    turn([[1,1],[1,0],[1,1],[1,0],[0,1],[1,1]])
  })
  makeButton((windowWidth - ButtonSize),100,"Blue","Random",false,false,()=>{
    const length = 20
    let arr = []
    for(let i = 0; i < length; i++)arr.push([Math.random() < 0.5, Math.random() < 0.5])
    turn(arr)
  })
  
}

function makeButton(x,y,col,txt,l,r,f){
  butt = createButton(txt).size(ButtonSize, ButtonSize/2);
  butt.position(x, y);
  butt.style('font-size', '30px');
  butt.style('background-color', color(col));
  butt.mousePressed(()  => {
    if (f){
      f()
    }else{
      leftMove = l
      rightMove = r
      setTimeout(resetMove, 500, l ,r);
    }
  });
}

function resetMove(l,r) {
  if(l) leftMove = false; 
  if(r) rightMove = false;
}

function turn(turns){
  setTimeout(async function(turns){
    console.log("hello")
    for(const t of turns){
      l = t[0]
      r = t[1]
      console.log(turns,t)
      console.log(l,r)
      leftMove = l
      rightMove = r
      await sleep(500)
    }
    
    resetMove(true,true)
  },0,turns)
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function draw() {
  background(0);
  stroke('red');
  
  if (leftMove) {
      fill(255);     
      strokeWeight(0); 
  }
  else {
      fill(0);
      strokeWeight(1);
  }
  // Draw a rectangle at (x, y, width, height , rounded corners).
  rect(10, windowHeight - 250 , (windowWidth/2) - 20, 200, 20);
  
  if (rightMove) {
      fill(255);     
      strokeWeight(0); 
  }
  else {
      fill(0);
      strokeWeight(1);
  }
  // Draw a rectangle at (x, y, width, height , rounded corners).
  rect((windowWidth/2) + 10, windowHeight - 250 , (windowWidth/2) - 20, 200, 20);
}
                    
                